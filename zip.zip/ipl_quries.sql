CREATE TABLE deliveries (
    match_id INT,
    inning INT,
    batting_team VARCHAR(100),
    bowling_team VARCHAR(100),
    over_no INT,
    ball INT,
    batter VARCHAR(100),
    bowler VARCHAR(100),
    non_striker VARCHAR(100),
    batsman_runs INT,
    extra_runs INT,
    total_runs INT,
    extras_type VARCHAR(50),
    is_wicket INT,
    player_dismissed VARCHAR(100),
    dismissal_kind VARCHAR(50),
    fielder VARCHAR(100)
);
select * from deliveries;

ALTER TABLE deliveries
ADD COLUMN delivery_id SERIAL PRIMARY KEY;



CREATE TABLE matches (
    match_id INT PRIMARY KEY,
    season VARCHAR(10),
    city VARCHAR(100),
    match_date DATE,
    match_type VARCHAR(50),
    player_of_match VARCHAR(100),
    venue VARCHAR(150),
    team1 VARCHAR(100),
    team2 VARCHAR(100),
    toss_winner VARCHAR(100),
    toss_decision VARCHAR(20),
    winner VARCHAR(100),
	result_by VARCHAR(100),
    result_margin INT,
    target_runs INT,
    target_overs DECIMAL(5,2),
    super_over VARCHAR(5),
    method_by VARCHAR(50),
    umpire1 VARCHAR(100),
    umpire2 VARCHAR(100)
);
select * from matches;

ALTER TABLE matches
RENAME COLUMN result_by TO result;

ALTER TABLE matches
RENAME COLUMN method_by TO method;


ALTER TABLE matches
ALTER COLUMN super_over TYPE BOOLEAN
USING (
    CASE 
        WHEN super_over IN ('Y','1','TRUE') THEN TRUE
        ELSE FALSE
    END
);



ALTER TABLE deliveries
ADD CONSTRAINT fk_match
FOREIGN KEY (match_id)
REFERENCES matches(match_id);




-- BASIC LEVEL

-- 1. Total Matches Played
SELECT COUNT(*) AS total_matches FROM matches;



-- 2. Total Runs Scored in IPL
SELECT SUM(total_runs) AS total_runs FROM deliveries;



-- 3. Distinct Teams
SELECT DISTINCT team1 FROM matches;



-- 4. Matches per Season
SELECT season, COUNT(*) AS total_matches
FROM matches
GROUP BY season
ORDER BY season;



-- 5. Total Sixes
SELECT COUNT(*) AS total_sixes
FROM deliveries
WHERE batsman_runs = 6;



-- INTERMEDIATE LEVEL

-- 6. Top 10 Batsmen (Runs)
SELECT batter, SUM(batsman_runs) AS runs
FROM deliveries
GROUP BY batter
ORDER BY runs DESC
LIMIT 10;



-- 7. Top 10 Bowlers (Wickets)
SELECT bowler, COUNT(*) AS wickets
FROM deliveries
WHERE is_wicket = 1
AND dismissal_kind NOT IN ('run out')
GROUP BY bowler
ORDER BY wickets DESC
LIMIT 10;



-- 8. Most Player of the Match Awards
SELECT player_of_match, COUNT(*) AS awards
FROM matches
GROUP BY player_of_match
ORDER BY awards DESC
LIMIT 10;



-- 9. Team with Most Wins
SELECT winner, COUNT(*) AS wins
FROM matches
GROUP BY winner
ORDER BY wins DESC;



-- 10. Toss Winner vs Match Winner
SELECT 
    COUNT(*) FILTER (WHERE toss_winner = winner) AS toss_win_match_win,
    COUNT(*) AS total_matches
FROM matches;



-- ADVANCED LEVEL

-- 11. Highest Team Score in a Match
SELECT match_id, batting_team, SUM(total_runs) AS total_score
FROM deliveries
GROUP BY match_id, batting_team
ORDER BY total_score DESC
LIMIT 1;



-- 12. Lowest Team Score
SELECT match_id, batting_team, SUM(total_runs) AS total_score
FROM deliveries
GROUP BY match_id, batting_team
ORDER BY total_score ASC
LIMIT 1;



-- 13. Best Strike Rate (min 1000 runs)
SELECT batter,
       SUM(batsman_runs) * 100.0 / COUNT(*) AS strike_rate
FROM deliveries
GROUP BY batter
HAVING SUM(batsman_runs) > 1000
ORDER BY strike_rate DESC
LIMIT 10;



-- 14. Economy Rate of Bowlers
SELECT bowler,
       SUM(total_runs) / (COUNT(*) / 6.0) AS economy
FROM deliveries
GROUP BY bowler
HAVING COUNT(*) > 300
ORDER BY economy ASC
LIMIT 10;



-- 15. Most Dot Balls
SELECT bowler, COUNT(*) AS dot_balls
FROM deliveries
WHERE total_runs = 0
GROUP BY bowler
ORDER BY dot_balls DESC
LIMIT 10;



-- JOIN QUERIES

-- 16. Runs by Season
SELECT m.season, SUM(d.total_runs) AS total_runs
FROM deliveries d
JOIN matches m ON d.match_id = m.match_id
GROUP BY m.season
ORDER BY m.season;



-- 17. Top Batsman Each Season
SELECT season, batter, runs
FROM (
    SELECT m.season, d.batter,
           SUM(d.batsman_runs) AS runs,
           RANK() OVER (PARTITION BY m.season ORDER BY SUM(d.batsman_runs) DESC) AS rnk
    FROM deliveries d
    JOIN matches m ON d.match_id = m.match_id
    GROUP BY m.season, d.batter
) t
WHERE rnk = 1;



-- 18. Most Wickets Each Season
SELECT season, bowler, wickets
FROM (
    SELECT m.season, d.bowler,
           COUNT(*) AS wickets,
           RANK() OVER (PARTITION BY m.season ORDER BY COUNT(*) DESC) AS rnk
    FROM deliveries d
    JOIN matches m ON d.match_id = m.match_id
    WHERE is_wicket = 1
    GROUP BY m.season, d.bowler
) t
WHERE rnk = 1;



-- 19. Team Win %
SELECT team,
       COUNT(*) FILTER (WHERE team = winner) * 100.0 
       / COUNT(*) FILTER (WHERE winner IS NOT NULL) AS win_percentage
FROM (
    SELECT team1 AS team, winner FROM matches
    UNION ALL
    SELECT team2 AS team, winner FROM matches
) t
GROUP BY team
ORDER BY win_percentage DESC;

-- 20. Most Runs in Death Overs (16–20)
SELECT batter, SUM(batsman_runs) AS runs
FROM deliveries
WHERE over_no BETWEEN 16 AND 20
GROUP BY batter
ORDER BY runs DESC
LIMIT 10;



-- 21. Boundary Percentage of Batsmen
SELECT batter,
       COUNT(*) FILTER (WHERE batsman_runs IN (4,6)) * 100.0 / COUNT(*) AS boundary_pct
FROM deliveries
GROUP BY batter
HAVING COUNT(*) > 500
ORDER BY boundary_pct DESC
LIMIT 10;



-- 22. Super Over Matches Count
SELECT COUNT(*) FROM matches
WHERE super_over = TRUE;



-- 23. Matches Affected by D/L Method
SELECT COUNT(*) FROM matches
WHERE method IS NOT NULL;



-- 24. Best Finisher (Last 5 Overs Strike Rate)
SELECT batter,
       SUM(batsman_runs) * 100.0 / COUNT(*) AS strike_rate
FROM deliveries
WHERE over_no BETWEEN 16 AND 20
GROUP BY batter
HAVING COUNT(*) > 200
ORDER BY strike_rate DESC
LIMIT 10;



-- 25. Most Consistent Player (Runs per Match)
SELECT batter,
       SUM(batsman_runs) * 1.0 / COUNT(DISTINCT match_id) AS avg_runs
FROM deliveries
GROUP BY batter
ORDER BY avg_runs DESC
LIMIT 10;



-- Advanced JOIN-Based SQL Insights

-- 26. Orange Cap Winner per Season (Top Scorer)
SELECT season, batter, runs
FROM (
    SELECT m.season, d.batter,
           SUM(d.batsman_runs) AS runs,
           RANK() OVER (PARTITION BY m.season ORDER BY SUM(d.batsman_runs) DESC) AS rnk
    FROM deliveries d
    JOIN matches m ON d.match_id = m.match_id
    GROUP BY m.season, d.batter
) t
WHERE rnk = 1;



-- 27. Purple Cap Winner (Most Wickets per Season)
SELECT season, bowler, wickets
FROM (
    SELECT m.season, d.bowler,
           COUNT(*) AS wickets,
           RANK() OVER (PARTITION BY m.season ORDER BY COUNT(*) DESC) AS rnk
    FROM deliveries d
    JOIN matches m ON d.match_id = m.match_id
    WHERE d.is_wicket = 1
    GROUP BY m.season, d.bowler
) t
WHERE rnk = 1;



-- 28. Best Economy Bowlers (Min 300 balls)
SELECT d.bowler,
       SUM(d.total_runs) / (COUNT(*) / 6.0) AS economy
FROM deliveries d
JOIN matches m ON d.match_id = m.match_id
GROUP BY d.bowler
HAVING COUNT(*) > 300
ORDER BY economy ASC
LIMIT 10;



-- 29. Most Impactful Player (Runs + Wickets Combined)
SELECT player,
       SUM(runs) AS total_runs,
       SUM(wickets) AS total_wickets,
       SUM(runs) + SUM(wickets) AS impact_score
FROM (
    -- Batting contribution
    SELECT batter AS player,
           SUM(batsman_runs) AS runs,
           0 AS wickets
    FROM deliveries
    GROUP BY batter

    UNION ALL

    -- Bowling contribution (exclude run outs)
    SELECT bowler AS player,
           0 AS runs,
           COUNT(*) AS wickets
    FROM deliveries
    WHERE is_wicket = 1
      AND dismissal_kind NOT IN ('run out')
    GROUP BY bowler
) t
GROUP BY player
ORDER BY impact_score DESC
LIMIT 10;



-- 30. Team Performance by Season
SELECT m.season, m.winner, COUNT(*) AS wins
FROM matches m
GROUP BY m.season, m.winner
ORDER BY m.season, wins DESC;



-- 31. Highest Run Chase (Winning Team Score in 2nd Innings)
SELECT m.match_id, m.winner, SUM(d.total_runs) AS chase_score
FROM deliveries d
JOIN matches m ON d.match_id = m.match_id
WHERE d.inning = 2
GROUP BY m.match_id, m.winner
ORDER BY chase_score DESC
LIMIT 10;



-- 32. Player Consistency (Runs per Match)
SELECT d.batter,
       SUM(d.batsman_runs) / COUNT(DISTINCT d.match_id) AS avg_runs
FROM deliveries d
JOIN matches m ON d.match_id = m.match_id
GROUP BY d.batter
HAVING COUNT(DISTINCT d.match_id) > 30
ORDER BY avg_runs DESC
LIMIT 10;



-- 33. Best Finisher (Death Overs Performance)
SELECT d.batter,
       SUM(d.batsman_runs) AS runs,
       COUNT(*) AS balls,
       SUM(d.batsman_runs) * 100.0 / COUNT(*) AS strike_rate
FROM deliveries d
JOIN matches m ON d.match_id = m.match_id
WHERE d.over_no BETWEEN 16 AND 20
GROUP BY d.batter
HAVING COUNT(*) > 200
ORDER BY strike_rate DESC
LIMIT 10;



-- 34. Toss Impact on Match Result
SELECT 
    COUNT(*) FILTER (WHERE toss_winner = winner) * 100.0 / COUNT(*) AS toss_win_percentage
FROM matches;



-- 35. Venue-wise Average Score
SELECT m.venue,
       AVG(total_score) AS avg_score
FROM (
    SELECT match_id, SUM(total_runs) AS total_score
    FROM deliveries
    GROUP BY match_id
) d
JOIN matches m ON d.match_id = m.match_id
GROUP BY m.venue
ORDER BY avg_score DESC;



-- 36. Most Sixes by Player per Season
SELECT season, batter, sixes
FROM (
    SELECT m.season, d.batter,
           COUNT(*) AS sixes,
           RANK() OVER (PARTITION BY m.season ORDER BY COUNT(*) DESC) AS rnk
    FROM deliveries d
    JOIN matches m ON d.match_id = m.match_id
    WHERE d.batsman_runs = 6
    GROUP BY m.season, d.batter
) t
WHERE rnk = 1;



-- 37. Powerplay Dominators (Overs 1–6)
SELECT d.batter,
       SUM(d.batsman_runs) AS runs
FROM deliveries d
JOIN matches m ON d.match_id = m.match_id
WHERE d.over_no BETWEEN 1 AND 6
GROUP BY d.batter
ORDER BY runs DESC
LIMIT 10;



-- 38. Best Bowling Performance in a Match
SELECT match_id, bowler,
       COUNT(*) AS wickets
FROM deliveries
WHERE is_wicket = 1
GROUP BY match_id, bowler
ORDER BY wickets DESC
LIMIT 10;



-- 39. Dot Ball Percentage (Pressure Bowlers)
SELECT bowler,
       COUNT(*) FILTER (WHERE total_runs = 0) * 100.0 / COUNT(*) AS dot_ball_pct
FROM deliveries
GROUP BY bowler
HAVING COUNT(*) > 300
ORDER BY dot_ball_pct DESC
LIMIT 10;



-- 40. Matches Won Batting First vs Chasing
SELECT 
    COUNT(*) FILTER (WHERE result = 'runs') AS batting_first_wins,
    COUNT(*) FILTER (WHERE result = 'wickets') AS chasing_wins
FROM matches;




